export default ( /^--/ );
