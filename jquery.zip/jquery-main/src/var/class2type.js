// [[Class]] -> type pairs
export default {};
